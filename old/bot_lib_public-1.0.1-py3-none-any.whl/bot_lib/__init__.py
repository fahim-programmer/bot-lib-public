from package.bot_lib import *

VERSION = "1.0.0"
AUTHOR = "Fahim Chohan"